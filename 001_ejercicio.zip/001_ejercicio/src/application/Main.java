package application;
	
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.layout.HBox;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;


public class Main extends Application {
	
	private ObservableList<Productos> productoo = FXCollections.observableArrayList();

    public Main() {
    	productoo.add(new Productos("Ducatti Paniagle", 2, 31000));
    	productoo.add(new Productos("Yamaha R1", 4, 15000));
        productoo.add(new Productos("Yamaha R6", 6, 11000));
        productoo.add(new Productos("BMW S1000R", 2, 21000));
        productoo.add(new Productos("Honda CBR1000", 4, 9800));
        productoo.add(new Productos("Kawashaki H2", 1, 35000));
        productoo.add(new Productos("Honda CBR600", 5, 8600));
    }
  
    public ObservableList<Productos> getProductoo() {
        return productoo;
    }
    
	@Override
	public void start(Stage firstStage) {
		try {
			FXMLLoader entrar = new FXMLLoader();
            entrar.setLocation(getClass().getResource("Sample.fxml"));
			HBox layouut = (HBox)entrar.load();
			Scene scenee = new Scene(layouut,500,500);
			scenee.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			
			SampleController controlador = entrar.getController();
			controlador.setMainApp(this);
			
			firstStage.setScene(scenee);
			firstStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
