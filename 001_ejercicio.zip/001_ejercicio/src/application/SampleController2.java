package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import application.Main;
import application.Productos;

public class SampleController2 {

	private Main main;

	@FXML
	private TableView<Productos> productoTable;
	@FXML
	private TableColumn<Productos, String> descripcionColumn;
	@FXML
	private TableColumn<Productos, Integer> stockColumn;

	@FXML
	private Label descripcion_txt;

	@FXML
	private Label precio_txt;

	@FXML
	private Label stock_txt;

	@FXML
	private Label fecha_txt;

	public SampleController2() {
	}
	@FXML
	private void initialize() {
		// Initialize the person table with the two columns.
		descripcionColumn.setCellValueFactory(cellData -> cellData.getValue().descripcionProperty());
		stockColumn.setCellValueFactory(cellData -> cellData.getValue().stockProperty().asObject());
		showProductosDetails(null);
		
		productoTable.getSelectionModel().selectedItemProperty().addListener(
	            (observable, oldValue, newValue) -> showProductosDetails(newValue));

	}

	public void setMainApp(Main main) {
		this.main = main;

		// Add observable list data to the table
		productoTable.setItems(this.main.getProductoo());
	}

	private void showProductosDetails(Productos productos) {
		if (productos != null) {
			// Fill the labels with info from the person object.
			descripcion_txt.setText(productos.getDescripcion());
			stock_txt.setText(Integer.toString(productos.getStock()));
			precio_txt.setText(Integer.toString(productos.getprecio()));
			fecha_txt.setText(DateUtil.format(productos.getfecha()));

			// TODO: We need a way to convert the birthday into a String!
			// birthdayLabel.setText(...);
		} else {
			// Person is null, remove all the text.
			descripcion_txt.setText("");
			stock_txt.setText("");
			precio_txt.setText("");
			fecha_txt.setText("");
		}
	}

}